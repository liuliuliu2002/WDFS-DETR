import warnings, os
warnings.filterwarnings('ignore')
from ultralytics import RTDETR
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'


if __name__ == '__main__':
    model = RTDETR(r'E:\网站下载\RTDETR-main\ultralytics\cfg\models\rt-detr\rtdetr-WTConv-MPCA.yaml')
    # model.load('') # loading pretrain weights
    model.train(data=r'E:\网站下载\RTDETR-main\ultralytics\cfg\datasets\VisDrone.yaml',
                cache=False,
                imgsz=640,
                epochs=100,
                batch=4,
                workers=4, # Windows下出现莫名其妙卡主的情况可以尝试把workers设置为0
                # device='0,1',
                # resume='', # last.pt path
                project='runs/train',
                name='ours',
                )